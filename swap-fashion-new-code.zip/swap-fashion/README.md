# UE Swap Fashion (PWA)
Swap, buy or bid on pre-loved clothes. UE students only.

## Run
Open the folder in VS Code / Codespaces and start a static server, e.g. `npx serve .` (or the Live Server extension), then open `index.html`.

## Test logins
- Student: 2021-10234 / maria@ue.edu.ph / password123
- Admin (pre-set): admin@ue.edu.ph / admin123

## Files
- `style.css` your original styles, `style2.css` extra styles (login, chat, nav, profile, feedback, admin)
- `app.js` all logic (login, items, cart, checkout, bids, inbox, admin). Data is kept in the browser (localStorage) for the demo.
