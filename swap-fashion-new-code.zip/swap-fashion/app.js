'use strict';
/* UE Swap Fashion - app logic. Demo data lives in the browser (localStorage). */
const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
const S = { get(k, d) { try { const v = JSON.parse(localStorage.getItem(k)); return v === null ? d : v; } catch (e) { return d; } }, set(k, v) { localStorage.setItem(k, JSON.stringify(v)); } };
const peso = n => '₱' + Number(n || 0).toLocaleString();
const q = new URLSearchParams(location.search);

const D = {
  cats: ['Formal Attire', 'Casual', 'Cosplay', 'Sportswear'],
  items: [
    { id: 1, t: 'Black Blazer', c: 'Formal Attire', size: 'M', cond: 'Good', seller: 'Maria Santos', modes: ['buy'], price: 350 },
    { id: 2, t: 'Pleated Skirt', c: 'Semi-formal', size: 'S', cond: 'Good', seller: 'Angela Reyes', modes: ['buy', 'swap', 'bid'], price: 220, start: 150 },
    { id: 3, t: 'Barong Tagalog', c: 'Formal Attire', size: 'L', cond: 'Like new', seller: 'John Dela Cruz', modes: ['swap'] },
    { id: 4, t: 'Basketball Jersey', c: 'Sportswear', size: 'L', cond: 'Good', seller: 'Mark Villanueva', modes: ['bid'], start: 100 },
    { id: 5, t: 'Denim Jacket', c: 'Casual', size: 'M', cond: 'Good', seller: 'Sofia Garcia', modes: ['buy', 'swap'], price: 400 }],
  accounts: [
    { name: 'Maria Santos', sn: '2021-10234', email: 'maria@ue.edu.ph', pass: 'password123', role: 'user' },
    { name: 'Administrator', sn: '', email: 'admin@ue.edu.ph', pass: 'admin123', role: 'admin' }],
  students: [['Maria Santos', '2021-10234'], ['John Dela Cruz', '2022-04519'], ['Angela Reyes', '2020-08812'], ['Mark Villanueva', '2023-01276'], ['Sofia Garcia', '2021-07731']],
  feedback: [['Maria Santos', '#10482', 'Swap', 5, 'Smooth swap! Met up at the campus gate.'], ['John Dela Cruz', '#10475', 'Purchase', 4, 'Seller shipped fast. Great value for the blazer.'],
    ['Angela Reyes', '#10461', 'Bid', 5, 'Won the auction and pickup was easy.'], ['Mark Villanueva', '#10449', 'Purchase', 3, 'Item was fine but the seller replied late.']],
  notifs: [['fa-gavel', 'You were outbid', 'Someone placed a higher bid on Pleated Skirt.', '5m', 1], ['fa-right-left', 'Swap accepted', 'Angela accepted your offer. Set a pickup time.', '1h', 1], ['fa-box', 'Order confirmed', 'Your order for Black Blazer is confirmed.', '1d', 0]],
  chats: [['Angela Reyes', 'AR', 'See you at the gate at 3pm!', '2m', 'Swap · #10482', 2], ['John Dela Cruz', 'JD', 'Thanks, I received the blazer.', '1h', 'Purchase · #10475', 0]]
};

const me = () => S.get('me', null);
function guard(role) { const u = me(); if (!u || u.role !== role) location.replace(role === 'admin' ? 'admin-login.html' : 'login.html'); }
function toast(m) { let t = $('.toast'); if (!t) { t = document.createElement('div'); t.className = 'toast'; document.body.appendChild(t); } t.textContent = m; t.classList.add('show'); setTimeout(() => t.classList.remove('show'), 1800); }
const cart = () => S.get('cart', []);
const item = id => D.items.find(x => x.id == id) || D.items[1];
const myBid = id => S.get('bids', {})[id] || 0;
const linePrice = x => { const i = item(x.id); return x.mode === 'buy' ? i.price : x.mode === 'bid' ? (myBid(x.id) || i.start) : 0; };
const badge = () => $$('.cartCount').forEach(e => e.textContent = cart().length);
function addToCart(id, mode) { const c = cart(); if (c.some(x => x.id == id && x.mode === mode)) return toast('Already in your cart'); c.push({ id: +id, mode }); S.set('cart', c); badge(); toast('Added to cart'); }
function logout() { localStorage.removeItem('me'); location.href = 'login.html'; }
function endTime() { let e = S.get('end', 0); if (e < Date.now()) { e = Date.now() + 8100000; S.set('end', e); } return e; }
function tick(el) { const f = () => { const s = Math.max(0, Math.floor((endTime() - Date.now()) / 1000)); el.textContent = [s / 3600, s % 3600 / 60, s % 60].map(n => String(Math.floor(n)).padStart(2, '0')).join(':'); }; f(); setInterval(f, 1000); }

function nav(active) {
  const admin = me() && me().role === 'admin';
  const t = admin ? [['admin-dashboard.html', 'fa-house', 'Dashboard'], ['manager-users.html', 'fa-users', 'Users'], ['manage-categories.html', 'fa-table-cells-large', 'Categories'], ['admin-feedback.html', 'fa-star', 'Feedback']]
    : [['home.html', 'fa-house', 'Home'], ['notifications.html', 'fa-bell', 'Notification'], ['FAB'], ['inbox.html', 'fa-envelope', 'Inbox'], ['profile.html', 'fa-user', 'Profile']];
  $('#nav').innerHTML = t.map(x => x[0] === 'FAB' ? '<button class="nav-fab" onclick="toast(\'Add-listing form coming soon\')"><i class="fa-solid fa-plus"></i></button>'
    : `<a class="nav-item${x[2] === active ? ' active' : ''}" href="${x[0]}"><i class="fa-solid ${x[1]}"></i>${x[2]}</a>`).join('');
}
function card(i) {
  const m = i.modes[0];
  const price = i.modes.includes('buy') ? `<div class="item-price">${peso(i.price)}</div>` : m === 'bid' ? '<div class="item-price swap-text">Bid hidden · 2h left</div>' : '<div class="item-price swap-text">Open to swap</div>';
  return `<a class="item-card" href="item-details-${m}.html?id=${i.id}"><div class="item-img"><i class="fa-solid fa-shirt item-icon"></i><span class="badge ${m}">${m[0].toUpperCase() + m.slice(1)}</span></div><h3>${i.t}</h3><p class="item-meta">${i.c} · Size ${i.size}</p>${price}</a>`;
}
const stars = n => '★'.repeat(n) + '☆'.repeat(5 - n);

const Pages = {
  login() {
    if (me()) location.replace(me().role === 'admin' ? 'admin-dashboard.html' : 'home.html');
    $('#goForm').onclick = () => { $('#welcome').classList.add('hidden'); $('#form').classList.remove('hidden'); $('#back').classList.remove('hidden'); };
    $('#back').onclick = e => { e.preventDefault(); $('#form').classList.add('hidden'); $('#back').classList.add('hidden'); $('#welcome').classList.remove('hidden'); };
    $('#gmail').onclick = () => toast('UE Gmail sign-in coming soon');
    $('#signin').onclick = () => {
      const sn = $('#sn').value.trim(), em = $('#em').value.trim().toLowerCase(), pw = $('#pw').value, m = $('#msg');
      if (!sn || !em || !pw) return m.textContent = 'Please fill in all fields.';
      const a = D.accounts.find(x => x.role === 'user' && x.sn === sn && x.email === em && x.pass === pw);
      if (!a) return m.textContent = 'Wrong details. Please try again.';
      if (S.get('banned', []).includes(a.sn)) return m.textContent = 'This account is banned.';
      S.set('me', a); location.href = 'home.html';
    };
  },
  adminLogin() {
    $('#signin').onclick = () => {
      const em = $('#em').value.trim().toLowerCase(), pw = $('#pw').value, m = $('#msg');
      const a = D.accounts.find(x => x.role === 'admin' && x.email === em && x.pass === pw);
      if (!a) return m.textContent = 'Access denied. This is not a pre-set admin account.';
      S.set('me', a); location.href = 'admin-dashboard.html';
    };
  },
  home() {
    guard('user'); nav('Home'); badge(); $('#uname').textContent = me().name.split(' ')[0];
    let cat = '', mode = 'all', text = ''; const cats = S.get('cats', D.cats);
    const draw = () => {
      $('#cats').innerHTML = cats.map(c => `<button class="category${c === cat ? ' active' : ''}" data-c="${c}"><i class="fa-solid fa-shirt"></i>${c}</button>`).join('') + '<button class="category add-new" id="addCat"><i class="fa-solid fa-plus"></i>Add</button>';
      $('#modes').innerHTML = ['all', 'buy', 'swap', 'bid'].map(m => `<button class="filter-pill${m === mode ? ' active' : ''}" data-m="${m}">${m[0].toUpperCase() + m.slice(1)}</button>`).join('');
      const list = D.items.filter(i => (!cat || i.c.split(' ')[0] === cat.split(' ')[0]) && (mode === 'all' || i.modes.includes(mode)) && i.t.toLowerCase().includes(text));
      $('#grid').innerHTML = list.map(card).join('') || '<p class="mode-hint">No match found.</p>';
      $$('[data-c]').forEach(b => b.onclick = () => { cat = cat === b.dataset.c ? '' : b.dataset.c; draw(); });
      $$('[data-m]').forEach(b => b.onclick = () => { mode = b.dataset.m; draw(); });
      $('#addCat').onclick = () => { const n = prompt('New category name'); if (n) { cats.push(n.trim()); S.set('cats', cats); draw(); } };
    };
    $('#q').oninput = e => { text = e.target.value.toLowerCase(); draw(); }; draw();
  },
  details(mode) {
    guard('user'); badge(); const i = item(q.get('id'));
    $('#cat').textContent = `${i.c} · Size ${i.size} · ${i.cond} condition`; $('#title').textContent = i.t; $('#seller').textContent = i.seller;
    $('#sav').textContent = i.seller.split(' ').map(w => w[0]).join('').slice(0, 2);
    const ic = { buy: 'fa-bag-shopping', swap: 'fa-right-left', bid: 'fa-gavel' };
    $('#modes').innerHTML = i.modes.map(m => `<a class="${mode}-mode-btn${m === mode ? ' active' : ''}" href="item-details-${m}.html?id=${i.id}"><i class="fa-solid ${ic[m]}"></i> ${m === 'buy' ? 'Buy ' + peso(i.price) : m[0].toUpperCase() + m.slice(1)}</a>`).join('');
    if (mode === 'buy') { $('#price').textContent = peso(i.price); $('#price2').textContent = peso(i.price); }
    if (mode !== 'bid') return $('#add').onclick = () => addToCart(i.id, mode);
    tick($('#timer')); let amt = (i.start || 100) + 90; const draw = () => $('#amt').textContent = peso(amt); draw();
    $$('[data-a]').forEach(b => b.onclick = () => { amt += +b.dataset.a; draw(); });
    $('#plus').onclick = () => { amt += 10; draw(); }; $('#minus').onclick = () => { amt = Math.max((i.start || 0) + 10, amt - 10); draw(); };
    $('#place').onclick = () => { const b = S.get('bids', {}); b[i.id] = amt; S.set('bids', b); const c = cart(); if (!c.some(x => x.id == i.id && x.mode === 'bid')) { c.push({ id: i.id, mode: 'bid' }); S.set('cart', c); } location.href = `bid-success.html?id=${i.id}&amt=${amt}`; };
  },
  bidSuccess() { guard('user'); $('#it').textContent = item(q.get('id')).t; $('#amt').textContent = peso(q.get('amt')); tick($('#timer')); },
  cart() {
    guard('user'); let mode = S.get('mode', 'purchase'); const key = { purchase: 'buy', swap: 'swap', bid: 'bid' };
    const hints = { purchase: 'Pay for your items, then the seller ships them to you.', swap: 'Offer one of your own items. The owner will accept or decline.', bid: 'Order the items you won in an auction. Amounts stay private.' };
    const draw = () => {
      const c = cart();
      $('#list').innerHTML = c.map((x, k) => { const i = item(x.id); return `<div class="cart-item"><div class="cart-item-img"><i class="fa-solid fa-shirt"></i></div><div class="cart-item-info"><div class="cart-item-top"><h3>${i.t}</h3><button class="delete-btn" data-k="${k}"><i class="fa-solid fa-trash"></i></button></div><div class="cart-item-meta">${i.c} · Size ${i.size}</div><span class="cart-item-tag">${{ buy: 'Buy', swap: 'Swap', bid: 'Bid' }[x.mode]}</span>${x.mode === 'swap' ? '' : `<div class="cart-item-price">${peso(linePrice(x))}</div>`}</div></div>`; }).join('') || '<p class="mode-hint">Your cart is empty.</p>';
      $$('.mode-btn').forEach(b => b.classList.toggle('active', b.dataset.m === mode)); $('#hint').textContent = hints[mode];
      const sel = c.filter(x => x.mode === key[mode]), sub = sel.reduce((s, x) => s + linePrice(x), 0), ship = sub ? 50 : 0;
      $('#offer').classList.toggle('hidden', mode !== 'swap'); $('#sumWrap').classList.toggle('hidden', mode === 'swap');
      $('#sub').textContent = peso(sub); $('#ship').textContent = peso(ship); $('#tot').textContent = $('#tot2').textContent = mode === 'swap' ? sel.length + ' item/s' : peso(sub + ship);
      $('#lbl').textContent = mode === 'swap' ? 'Items' : 'Total';
      $$('.delete-btn').forEach(b => b.onclick = () => { c.splice(+b.dataset.k, 1); S.set('cart', c); draw(); });
    };
    $$('.mode-btn').forEach(b => b.onclick = () => { mode = b.dataset.m; S.set('mode', mode); draw(); });
    $('#clear').onclick = () => { S.set('cart', []); draw(); };
    $('#offer').onclick = () => toast('Pick one of your items to offer (coming soon)');
    $('#order').onclick = () => cart().some(x => x.mode === key[mode]) ? location.href = 'checkout.html?mode=' + mode : toast('No ' + mode + ' items in your cart');
    draw();
  },
  checkout() {
    guard('user'); const mode = q.get('mode') || 'purchase', key = { purchase: 'buy', swap: 'swap', bid: 'bid' }[mode];
    const sel = cart().filter(x => x.mode === key), sub = sel.reduce((s, x) => s + linePrice(x), 0), ship = mode === 'swap' || !sub ? 0 : 50;
    $('#sub').textContent = peso(sub); $('#ship').textContent = peso(ship); $('#tot').textContent = peso(sub + ship); $('#kind').textContent = mode[0].toUpperCase() + mode.slice(1);
    const days = [...Array(4)].map((_, k) => { const d = new Date(); d.setDate(d.getDate() + k + 1); return d; }), times = ['9:00 AM', '10:30 AM', '1:00 PM', '2:30 PM', '4:00 PM', '5:30 PM'];
    let di = 0, ti = 0; const sum = () => $('#sched').textContent = `Meet-up: ${days[di].toLocaleDateString('en', { weekday: 'long', month: 'short', day: 'numeric' })} · ${times[ti]}`;
    $('#dates').innerHTML = days.map((d, k) => `<button class="date-btn${k ? '' : ' active'}" data-k="${k}"><span>${d.toLocaleDateString('en', { weekday: 'short' })}</span><strong>${d.getDate()}</strong></button>`).join('');
    $('#times').innerHTML = times.map((t, k) => `<button class="time-btn${k ? '' : ' active'}${k === 3 ? ' disabled' : ''}" data-k="${k}">${t}</button>`).join('');
    $$('.date-btn').forEach(b => b.onclick = () => { di = +b.dataset.k; $$('.date-btn').forEach(x => x.classList.toggle('active', x === b)); sum(); });
    $$('.time-btn').forEach(b => b.onclick = () => { if (b.classList.contains('disabled')) return; ti = +b.dataset.k; $$('.time-btn').forEach(x => x.classList.toggle('active', x === b)); sum(); }); sum();
    $('#confirm').onclick = () => {
      S.set('cart', cart().filter(x => x.mode !== key)); $('#formView').classList.add('hidden'); $('#done').classList.remove('hidden');
      $('#doneT').textContent = mode === 'swap' ? 'Swap confirmed!' : 'Order confirmed!';
      $('#doneP').textContent = (mode === 'swap' ? 'We messaged the other student so you can plan the swap.' : 'Your pickup is set.') + ' ' + $('#sched').textContent;
      if (mode === 'swap') S.set('swapNote', true);
    };
    let rate = 0; $$('.star').forEach(b => b.onclick = () => { rate = +b.dataset.s; $$('.star').forEach(x => x.classList.toggle('active', +x.dataset.s <= rate)); });
    $('#sendFb').onclick = () => { if (!rate) return toast('Tap a star rating first'); const f = S.get('feedback', []); f.push([me().name, rate, $('#fb').value]); S.set('feedback', f); toast('Thanks for your feedback!'); setTimeout(() => location.href = 'home.html', 900); };
  },
  notifs() {
    guard('user'); nav('Notification'); let f = 'all', read = S.get('read', false);
    const draw = () => { $('#list').innerHTML = D.notifs.filter(n => f === 'all' || (n[4] && !read)).map(n => `<div class="notif-card${n[4] && !read ? ' unread' : ''}"><div class="notif-icon"><i class="fa-solid ${n[0]}"></i></div><div class="notif-content"><div class="notif-title-text">${n[1]}</div><div class="notif-desc">${n[2]}</div></div><span class="notif-time">${n[3]}</span>${n[4] && !read ? '<span class="unread-dot"></span>' : ''}</div>`).join('') || '<p class="mode-hint" style="padding:0 20px">Nothing new.</p>'; };
    $$('[data-f]').forEach(b => b.onclick = () => { f = b.dataset.f; $$('[data-f]').forEach(x => x.classList.toggle('active', x === b)); draw(); });
    $('#readAll').onclick = () => { read = true; S.set('read', true); draw(); }; draw();
  },
  inbox() {
    guard('user'); nav('Inbox');
    $('#chats').innerHTML = D.chats.map((c, k) => `<div class="chat-card" data-k="${k}"><div class="chat-avatar">${c[1]}</div><div class="chat-info"><div class="chat-header"><span class="chat-name">${c[0]}</span><span class="chat-time">${c[3]}</span></div><div class="chat-message">${c[2]}</div><span class="chat-tag">${c[4]}</span></div>${c[5] ? `<div class="chat-unread">${c[5]}</div>` : ''}</div>`).join('');
    const add = (cls, txt) => { $('#msgs').insertAdjacentHTML('beforeend', `<div class="message ${cls}">${txt}</div>`); $('#msgs').scrollTop = 1e6; };
    $$('.chat-card').forEach(el => el.onclick = () => {
      const c = D.chats[el.dataset.k]; $('#listView').classList.add('hidden'); $('#chatView').classList.add('active'); $('#nav').classList.add('hidden');
      $('#cav').textContent = c[1]; $('#cname').textContent = c[0]; $('#ctx').textContent = c[4]; $('#msgs').innerHTML = '';
      if (S.get('swapNote', false) || /Swap/.test(c[4])) add('system', 'Swap confirmed. Message each other to set the pickup.');
      add('received', c[2]);
    });
    $('#chatBack').onclick = () => { $('#chatView').classList.remove('active'); $('#listView').classList.remove('hidden'); $('#nav').classList.remove('hidden'); };
    const send = () => { const v = $('#msgIn').value.trim(); if (v) { add('sent', v); $('#msgIn').value = ''; } };
    $('#send').onclick = send; $('#msgIn').onkeydown = e => { if (e.key === 'Enter') send(); };
  },
  profile() {
    guard('user'); nav('Profile'); const u = me(); $('#av').textContent = u.name.split(' ').map(w => w[0]).join('').slice(0, 2); $('#pn').textContent = u.name; $('#ps').textContent = u.sn + ' · ' + u.email;
    const cats = S.get('cats', D.cats), draw = () => { $('#chips').innerHTML = cats.map(c => `<button class="category-chip active">${c}</button>`).join('') + '<button class="category-chip add" id="addC">+ Add</button>'; $('#addC').onclick = () => { const n = prompt('New category name'); if (n) { cats.push(n.trim()); S.set('cats', cats); draw(); } }; }; draw();
    $$('.menu-row').forEach(r => r.onclick = () => toast(r.dataset.t)); $('#logout').onclick = logout;
  },
  adminDash() { guard('admin'); nav('Dashboard'); $('#who').textContent = 'Signed in as ' + me().email; $('#logout').onclick = logout; },
  adminFeedback() {
    guard('admin'); nav('Feedback'); const all = D.feedback.concat(S.get('feedback', []).map(f => [f[0], '#new', 'Order', f[1], f[2] || '(no comment)']));
    $('#avg').textContent = (all.reduce((s, f) => s + f[3], 0) / all.length).toFixed(1); $('#cnt').textContent = all.length + ' reviews';
    $('#list').innerHTML = all.map(f => `<div class="feedback-card"><div class="feedback-meta"><strong style="font-size:13.5px;color:#2A1517">${f[0]}</strong><span>Txn ${f[1]} · ${f[2]}</span></div><div class="stars">${stars(f[3])}</div><p>${f[4]}</p></div>`).join('');
  },
  manageCats() {
    guard('admin'); nav('Categories'); const cats = S.get('cats', D.cats);
    const draw = () => { $('#list').innerHTML = cats.map((c, k) => `<div class="manage-card"><div class="icon"><i class="fa-solid fa-shirt"></i></div><div style="flex:1"><h3>${c}</h3></div><button class="ban-btn" data-e="${k}" style="border-color:#A51C10;color:#A51C10">Edit</button><button class="ban-btn" data-d="${k}">Remove</button></div>`).join('');
      $$('[data-e]').forEach(b => b.onclick = () => { const n = prompt('Rename category', cats[b.dataset.e]); if (n) { cats[b.dataset.e] = n.trim(); S.set('cats', cats); draw(); } });
      $$('[data-d]').forEach(b => b.onclick = () => { if (confirm('Remove this category?')) { cats.splice(b.dataset.d, 1); S.set('cats', cats); draw(); } }); };
    $('#add').onclick = () => { const n = prompt('New category name'); if (n) { cats.push(n.trim()); S.set('cats', cats); draw(); } }; draw();
  },
  manageUsers() {
    guard('admin'); nav('Users'); const draw = () => { const ban = S.get('banned', []);
      $('#list').innerHTML = D.students.map(s => { const b = ban.includes(s[1]); return `<div class="user-row"><div class="chat-avatar" style="width:40px;height:40px;font-size:12px">${s[0].split(' ').map(w => w[0]).join('').slice(0, 2)}</div><div class="info"><h3>${s[0]}</h3><p>${s[1]}</p><span class="status-pill ${b ? 'banned' : 'active'}">${b ? 'Banned' : 'Active'}</span></div><button class="${b ? 'unban-btn' : 'ban-btn'}" data-s="${s[1]}">${b ? 'Unban' : 'Ban'}</button></div>`; }).join('');
      $$('[data-s]').forEach(x => x.onclick = () => { const a = S.get('banned', []), i = a.indexOf(x.dataset.s); i < 0 ? a.push(x.dataset.s) : a.splice(i, 1); S.set('banned', a); draw(); }); }; draw();
  }
};
